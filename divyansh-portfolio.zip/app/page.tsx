import { ThemeProvider } from "@/components/theme-provider"
import { HeroSection } from "@/components/hero-section"
import { AboutSection } from "@/components/about-section"
import { ServicesSection } from "@/components/services-section"
import { EducationSection } from "@/components/education-section"
import { ProjectsSection } from "@/components/projects-section"
import { CertificatesSection } from "@/components/certificates-section"
import { ContactSection } from "@/components/contact-section"
import { Navigation } from "@/components/navigation"
import { BackgroundEffects } from "@/components/background-effects"

export default function Home() {
  return (
    <ThemeProvider attribute="class" defaultTheme="dark" enableSystem>
      <div className="min-h-screen bg-background text-foreground relative overflow-hidden">
        <BackgroundEffects />
        <Navigation />
        <HeroSection />
        <AboutSection />
        <ServicesSection />
        <EducationSection />
        <ProjectsSection />
        <CertificatesSection />
        <ContactSection />
      </div>
    </ThemeProvider>
  )
}
