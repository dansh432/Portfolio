"use client"

import { ExternalLink, Github } from "lucide-react"
import { Button } from "@/components/ui/button"
import Image from "next/image"

export function ProjectsSection() {
  const projects = [
    {
      title: "Apni Trip - Ride Booking App",
      description:
        "A comprehensive ride booking application with real-time tracking, multiple vehicle options, and route optimization. Built with modern web technologies for seamless user experience.",
      image: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/image-dUWyMqsuZNqiwMph461vxsw3U9SmcQ.png",
      technologies: ["React", "Node.js", "MongoDB", "Express.js", "Maps API"],
      liveDemo: "https://apnitrip.vercel.app/",
      github: "https://github.com/divyansh-mishra",
      category: "Full Stack Application",
    },
    {
      title: "Recipe Finder App",
      description:
        "A modern recipe management application with advanced search functionality, favorites system, and detailed cooking instructions. Features a clean, intuitive interface.",
      image: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/image-F8MlrQHdkPWZFvrb1zz95Qze78GJOb.png",
      technologies: ["React", "Node.js", "MongoDB", "Express.js", "Recipe API"],
      liveDemo: "https://recipeapp-demo.vercel.app/",
      github: "https://github.com/divyansh-mishra",
      category: "Web Application",
    },
  ]

  return (
    <section id="projects" className="py-20 px-4 bg-muted/50 relative z-10">
      <div className="max-w-7xl mx-auto">
        <div className="text-center mb-16">
          <p className="text-purple-400 text-lg mb-4">• Projects</p>
          <h2 className="text-3xl lg:text-4xl font-bold text-foreground mb-4">My Recent Works</h2>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
          {projects.map((project, index) => (
            <div key={index} className="group hover:scale-105 transition-all duration-300">
              <div className="bg-card border border-purple-500/20 rounded-lg overflow-hidden hover:border-purple-400/50 transition-all duration-300 hover:shadow-lg hover:shadow-purple-500/20">
                <div className="relative overflow-hidden">
                  <Image
                    src={project.image || "/placeholder.svg"}
                    alt={project.title}
                    width={500}
                    height={300}
                    className="w-full h-64 object-cover group-hover:scale-110 transition-transform duration-300"
                  />
                  <div className="absolute inset-0 bg-black/50 opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex items-center justify-center space-x-4">
                    <Button
                      size="sm"
                      className="bg-purple-400 text-black hover:bg-purple-500"
                      onClick={() => window.open(project.liveDemo, "_blank")}
                    >
                      <ExternalLink className="h-4 w-4 mr-2" />
                      Live Demo
                    </Button>
                    <Button
                      size="sm"
                      variant="outline"
                      className="border-white text-white hover:bg-white hover:text-black"
                      onClick={() => window.open(project.github, "_blank")}
                    >
                      <Github className="h-4 w-4 mr-2" />
                      Code
                    </Button>
                  </div>
                </div>

                <div className="p-6">
                  <div className="flex items-center justify-between mb-3">
                    <span className="text-purple-400 text-sm font-medium">{project.category}</span>
                  </div>

                  <h3 className="text-xl font-bold text-foreground mb-3">{project.title}</h3>
                  <p className="text-muted-foreground mb-4 leading-relaxed">{project.description}</p>

                  <div className="flex flex-wrap gap-2 mb-4">
                    {project.technologies.map((tech, techIndex) => (
                      <span key={techIndex} className="px-3 py-1 bg-purple-400/20 text-purple-400 text-sm rounded-full">
                        {tech}
                      </span>
                    ))}
                  </div>

                  <div className="flex space-x-4">
                    <button
                      onClick={() => window.open(project.liveDemo, "_blank")}
                      className="text-purple-400 hover:text-purple-300 font-medium transition-colors"
                    >
                      Live Demo
                    </button>
                    <button
                      onClick={() => window.open(project.github, "_blank")}
                      className="text-muted-foreground hover:text-foreground font-medium transition-colors"
                    >
                      View on Github
                    </button>
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}
