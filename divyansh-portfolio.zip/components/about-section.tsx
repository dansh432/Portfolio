"use client"

export function AboutSection() {
  return (
    <section id="about" className="py-20 px-4 relative z-10">
      <div className="max-w-4xl mx-auto">
        <div className="text-center mb-12">
          <h2 className="text-3xl lg:text-4xl font-bold mb-4">
            <span className="text-purple-400">About</span> Me
          </h2>
          <div className="w-20 h-1 bg-purple-400 mx-auto"></div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
          <div className="group hover:scale-105 transition-transform duration-300">
            <h3 className="text-2xl font-bold mb-6 text-purple-400">Who I Am</h3>
            <p className="text-muted-foreground mb-6 leading-relaxed">
              I'm a passionate Java Developer and Blockchain enthusiast currently pursuing B.Tech with specialization in
              Blockchain Technology from Lakshmi Narain College of Technology and Science, Bhopal, with a CGPA of 7.00.
            </p>
            <p className="text-muted-foreground mb-6 leading-relaxed">
              My expertise lies in Java development, blockchain technology, and full-stack web development using the
              MERN stack. I'm passionate about creating decentralized applications and building robust, scalable
              solutions.
            </p>
            <p className="text-muted-foreground leading-relaxed">
              When I'm not coding or exploring blockchain technologies, you'll find me playing chess (1300+ rating on
              chess.com), playing cricket at the district level, or enjoying box cricket with friends.
            </p>
          </div>

          <div className="group hover:scale-105 transition-transform duration-300">
            <h3 className="text-2xl font-bold mb-6 text-purple-400">Quick Facts</h3>
            <div className="space-y-4">
              <div className="flex items-center hover:text-purple-400 transition-colors">
                <span className="text-purple-400 font-semibold w-32">Location:</span>
                <span className="text-muted-foreground">Bhopal, India</span>
              </div>
              <div className="flex items-center hover:text-purple-400 transition-colors">
                <span className="text-purple-400 font-semibold w-32">Education:</span>
                <span className="text-muted-foreground">B.Tech Blockchain (2021-Present)</span>
              </div>
              <div className="flex items-center hover:text-purple-400 transition-colors">
                <span className="text-purple-400 font-semibold w-32">Primary Lang:</span>
                <span className="text-muted-foreground">Java</span>
              </div>
              <div className="flex items-center hover:text-purple-400 transition-colors">
                <span className="text-purple-400 font-semibold w-32">Specialization:</span>
                <span className="text-muted-foreground">Blockchain Technology</span>
              </div>
              <div className="flex items-center hover:text-purple-400 transition-colors">
                <span className="text-purple-400 font-semibold w-32">Experience:</span>
                <span className="text-muted-foreground">Freelance Developer (2022-Present)</span>
              </div>
              <div className="flex items-center hover:text-purple-400 transition-colors">
                <span className="text-purple-400 font-semibold w-32">Interests:</span>
                <span className="text-muted-foreground">Chess, Cricket, Gaming</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}
