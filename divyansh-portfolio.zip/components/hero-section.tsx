"use client"

import { Button } from "@/components/ui/button"
import { Download, ExternalLink } from "lucide-react"
import Image from "next/image"

export function HeroSection() {
  const handleDownloadResume = () => {
    const link = document.createElement("a")
    link.href = "https://drive.google.com/uc?export=download&id=1NRP-xlKmFqeVzTKqgCH9XkUS1Gea4byh"
    link.download = "Divyansh_Mishra_Resume.pdf"
    document.body.appendChild(link)
    link.click()
    document.body.removeChild(link)
  }

  return (
    <section className="min-h-screen flex items-center justify-center px-4 pt-20 relative z-10">
      <div className="max-w-7xl mx-auto grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
        {/* Profile Image */}
        <div className="flex justify-center lg:justify-start">
          <div className="relative group">
            <div className="w-80 h-80 rounded-full overflow-hidden border-4 border-purple-400/20 group-hover:border-purple-400/50 transition-all duration-300 group-hover:scale-105">
              <Image
                src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/WhatsApp%20Image%202025-06-25%20at%2008.12.54_ab101e02.jpg-A6gqdih4n4w0wzGqwfTFeR69Bmlh3V.jpeg"
                alt="Divyansh Mishra"
                width={320}
                height={320}
                className="w-full h-full object-cover"
              />
            </div>
            <div className="absolute -bottom-4 -right-4 w-16 h-16 bg-purple-400 rounded-full flex items-center justify-center group-hover:bg-purple-500 transition-colors duration-300">
              <span className="text-black text-2xl font-bold">{"<>"}</span>
            </div>
          </div>
        </div>

        {/* Hero Content */}
        <div className="text-center lg:text-left">
          <div className="mb-6">
            <span className="text-purple-400 text-lg">{"<span>"}</span>
            <span className="text-muted-foreground text-lg"> Hey, I'm Divyansh </span>
            <span className="text-purple-400 text-lg">{"</span>"}</span>
          </div>

          <h1 className="text-4xl lg:text-6xl font-bold mb-6">
            <span className="text-foreground">Java Developer</span>
            <br />
            <span className="text-purple-400">{"{"}</span>
            <span className="text-purple-400">Blockchain</span>
            <span className="text-purple-400">{"}"}</span>
            <br />
            <span className="text-foreground">Full Stack Developer</span>
            <span className="text-foreground">_</span>
          </h1>

          <div className="mb-8">
            <span className="text-purple-400">{"<p>"}</span>
            <p className="text-muted-foreground text-lg inline">
              {" "}
              Specializing in Java development and blockchain technology, I create robust, scalable solutions with
              modern web technologies and innovative approaches.{" "}
            </p>
            <span className="text-purple-400">{"</p>"}</span>
          </div>

          <div className="flex flex-wrap gap-4 mb-8">
            <div className="flex items-center space-x-2 text-purple-400 hover:scale-105 transition-transform">
              <div className="w-8 h-8 bg-purple-400/20 rounded flex items-center justify-center">
                <span className="text-xs font-bold">J</span>
              </div>
              <span>Java</span>
            </div>
            <div className="flex items-center space-x-2 text-purple-400 hover:scale-105 transition-transform">
              <div className="w-8 h-8 bg-purple-400/20 rounded flex items-center justify-center">
                <span className="text-xs font-bold">⛓️</span>
              </div>
              <span>Blockchain</span>
            </div>
            <div className="flex items-center space-x-2 text-purple-400 hover:scale-105 transition-transform">
              <div className="w-8 h-8 bg-purple-400/20 rounded flex items-center justify-center">
                <span className="text-xs font-bold">R</span>
              </div>
              <span>React</span>
            </div>
            <div className="flex items-center space-x-2 text-purple-400 hover:scale-105 transition-transform">
              <div className="w-8 h-8 bg-purple-400/20 rounded flex items-center justify-center">
                <span className="text-xs font-bold">N</span>
              </div>
              <span>Node.js</span>
            </div>
            <span className="text-muted-foreground">... and more</span>
          </div>

          <div className="flex flex-wrap gap-4">
            <Button
              onClick={handleDownloadResume}
              className="bg-purple-400 text-black hover:bg-purple-500 hover:scale-105 transition-all duration-300"
            >
              <Download className="mr-2 h-4 w-4" />
              Download Resume
            </Button>
            <Button
              variant="outline"
              className="border-purple-400 text-purple-400 hover:bg-purple-400 hover:text-black hover:scale-105 transition-all duration-300"
            >
              <ExternalLink className="mr-2 h-4 w-4" />
              View Projects
            </Button>
          </div>
        </div>
      </div>
    </section>
  )
}
