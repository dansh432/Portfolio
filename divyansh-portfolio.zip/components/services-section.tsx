import { Code, Database, Zap, RefreshCw, ShoppingCart, Sparkles } from "lucide-react"

export function ServicesSection() {
  const services = [
    {
      icon: Code,
      title: "Web & App Development",
      description:
        "Crafting visually appealing and user-friendly interfaces using Java, JavaScript, MERN stack, and modern frameworks like React and Node.js.",
    },
    {
      icon: Database,
      title: "Database Management",
      description:
        "Designing and implementing robust database solutions using MongoDB and SQL, ensuring efficient data storage and retrieval.",
    },
    {
      icon: Zap,
      title: "API Development",
      description:
        "Building scalable RESTful APIs and backend services that power modern web applications with optimal performance.",
    },
    {
      icon: RefreshCw,
      title: "Performance Optimization",
      description:
        "Optimizing application performance through efficient coding practices, database optimization, and modern development techniques.",
    },
    {
      icon: ShoppingCart,
      title: "E-commerce Solutions",
      description:
        "Developing comprehensive e-commerce platforms with secure payment integration and user-friendly shopping experiences.",
    },
    {
      icon: Sparkles,
      title: "Interactive UI/UX",
      description:
        "Creating engaging user interfaces with Three.js animations and modern CSS frameworks like Tailwind CSS.",
    },
  ]

  return (
    <section id="services" className="py-20 px-4 bg-gray-900/50">
      <div className="max-w-7xl mx-auto">
        <div className="text-center mb-16">
          <p className="text-emerald-400 text-lg mb-4">What do I offer</p>
          <h2 className="text-3xl lg:text-4xl font-bold mb-4">
            <span className="text-white">Designing Solutions</span>{" "}
            <span className="text-gray-400">Customized to Meet</span>
            <br />
            <span className="text-gray-400">Your Requirements</span>
          </h2>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8 mb-16">
          {services.map((service, index) => (
            <div
              key={index}
              className="bg-gray-800/50 border border-gray-700 rounded-lg p-6 hover:border-emerald-400/50 transition-colors group"
            >
              <div className="mb-4">
                <service.icon className="h-8 w-8 text-emerald-400 group-hover:scale-110 transition-transform" />
              </div>
              <h3 className="text-xl font-bold mb-3 text-white">{service.title}</h3>
              <p className="text-gray-400 leading-relaxed">{service.description}</p>
            </div>
          ))}
        </div>

        <div className="text-center">
          <p className="text-gray-400 text-lg mb-4">Excited to take on new projects and collaborate,</p>
          <p className="text-gray-400 text-lg">
            let's chat about your ideas.{" "}
            <a href="#contact" className="text-emerald-400 hover:underline">
              Reach Out
            </a>
          </p>
        </div>
      </div>
    </section>
  )
}
