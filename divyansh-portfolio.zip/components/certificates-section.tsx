"use client"

import { Award, ExternalLink } from "lucide-react"
import { Button } from "@/components/ui/button"

export function CertificatesSection() {
  const certificates = [
    {
      title: "Alpha (DSA with Java)",
      issuer: "Apna College",
      date: "2024",
      description: "Comprehensive course covering Data Structures and Algorithms using Java programming language.",
      image: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/image-hMlDVo59XPVKkPYXs7rsRz0OK84ntc.png",
      skills: ["Java", "Data Structures", "Algorithms"],
    },
    {
      title: "Introduction to Cyber Security",
      issuer: "Infosys Springboard",
      date: "February 6, 2024",
      description: "Foundational course covering cybersecurity principles, threats, and protection strategies.",
      image: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/image-4F4KIw0OJ3oIt8GAf7GQlan6juT8Jd.png",
      skills: ["Cybersecurity", "Network Security", "Risk Assessment"],
    },
    {
      title: "Introduction to Artificial Intelligence",
      issuer: "LinkedIn Learning",
      date: "October 15, 2024",
      description: "Comprehensive introduction to AI concepts, machine learning, and business applications.",
      image: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/image-x13YvIq0voF7Eg8uSGefMY6UE5i1us.png",
      skills: ["Artificial Intelligence", "Machine Learning", "AI for Business"],
      cpe: "3.20 CPE Credits",
    },
  ]

  return (
    <section id="certificates" className="py-20 px-4 relative z-10">
      <div className="max-w-7xl mx-auto">
        <div className="text-center mb-16">
          <div className="flex items-center justify-center mb-4">
            <Award className="h-8 w-8 text-purple-400 mr-3" />
            <h2 className="text-3xl lg:text-4xl font-bold text-foreground">Certificates & Achievements</h2>
          </div>
          <div className="w-20 h-1 bg-purple-400 mx-auto"></div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8 mb-16">
          {certificates.map((cert, index) => (
            <div
              key={index}
              className="bg-card border border-purple-500/20 rounded-lg overflow-hidden hover:border-purple-400/50 transition-all duration-300 group hover:scale-105 hover:shadow-lg hover:shadow-purple-500/20"
            >
              <div
                className="h-48 relative overflow-hidden rounded-t-lg"
                style={{
                  backgroundImage: `url(${cert.image})`,
                  backgroundSize: "cover",
                  backgroundPosition: "center",
                }}
              >
                <div className="absolute inset-0 bg-black/20 group-hover:bg-black/10 transition-all duration-300"></div>
              </div>

              <div className="p-6">
                <h3 className="text-xl font-bold text-foreground mb-2">{cert.title}</h3>
                <div className="flex items-center justify-between mb-3">
                  <span className="text-purple-400 font-medium">{cert.issuer}</span>
                  <span className="text-muted-foreground text-sm">{cert.date}</span>
                </div>

                <p className="text-muted-foreground text-sm mb-4 leading-relaxed">{cert.description}</p>

                {cert.cpe && <p className="text-purple-400 text-sm mb-4 font-medium">{cert.cpe}</p>}

                <div className="flex flex-wrap gap-2 mb-4">
                  {cert.skills.map((skill, skillIndex) => (
                    <span key={skillIndex} className="px-2 py-1 bg-purple-400/20 text-purple-400 text-xs rounded-full">
                      {skill}
                    </span>
                  ))}
                </div>

                <Button
                  variant="outline"
                  size="sm"
                  className="w-full border-purple-400 text-purple-400 hover:bg-purple-400 hover:text-black"
                >
                  <ExternalLink className="h-4 w-4 mr-2" />
                  View Certificate
                </Button>
              </div>
            </div>
          ))}
        </div>

        {/* Extracurricular Activities */}
        <div className="mt-16">
          <h3 className="text-2xl font-bold text-center mb-8 text-purple-400">Extracurricular Activities</h3>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            <div className="text-center p-6 bg-card/50 rounded-lg hover:scale-105 transition-transform duration-300 border border-purple-500/20 hover:border-purple-400/50">
              <div className="text-3xl mb-3">♟️</div>
              <h4 className="text-lg font-semibold text-foreground mb-2">Chess Player</h4>
              <p className="text-muted-foreground">1300+ Rating on chess.com</p>
            </div>
            <div className="text-center p-6 bg-card/50 rounded-lg hover:scale-105 transition-transform duration-300 border border-purple-500/20 hover:border-purple-400/50">
              <div className="text-3xl mb-3">🏏</div>
              <h4 className="text-lg font-semibold text-foreground mb-2">Cricket Player</h4>
              <p className="text-muted-foreground">District level cricket player</p>
            </div>
            <div className="text-center p-6 bg-card/50 rounded-lg hover:scale-105 transition-transform duration-300 border border-purple-500/20 hover:border-purple-400/50">
              <div className="text-3xl mb-3">🎯</div>
              <h4 className="text-lg font-semibold text-foreground mb-2">Box Cricket</h4>
              <p className="text-muted-foreground">Avid Box Cricket Enthusiast</p>
            </div>
            <div className="text-center p-6 bg-card/50 rounded-lg hover:scale-105 transition-transform duration-300 border border-purple-500/20 hover:border-purple-400/50">
              <div className="text-3xl mb-3">💼</div>
              <h4 className="text-lg font-semibold text-foreground mb-2">Deloitte Simulation</h4>
              <p className="text-muted-foreground">Technology Job Simulation - June 2025</p>
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}
