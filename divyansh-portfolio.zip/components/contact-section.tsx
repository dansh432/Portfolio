"use client"

import type React from "react"

import { Mail, Phone, MapPin, Github, Linkedin } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { useState } from "react"

export function ContactSection() {
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    subject: "",
    message: "",
  })

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    const { name, email, subject, message } = formData
    const mailtoLink = `mailto:mishradiv2002@gmail.com?subject=${encodeURIComponent(subject)}&body=${encodeURIComponent(
      `Name: ${name}\nEmail: ${email}\n\nMessage:\n${message}`,
    )}`
    window.location.href = mailtoLink
  }

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    setFormData((prev) => ({
      ...prev,
      [e.target.name]: e.target.value,
    }))
  }

  return (
    <section id="contact" className="py-20 px-4 bg-muted/50 relative z-10">
      <div className="max-w-7xl mx-auto">
        <div className="text-center mb-16">
          <h2 className="text-3xl lg:text-4xl font-bold text-foreground mb-4">
            Let's <span className="text-purple-400">Connect</span>
          </h2>
          <p className="text-muted-foreground text-lg max-w-2xl mx-auto">
            Ready to bring your ideas to life? Let's discuss your next project and create something amazing together.
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
          {/* Contact Information */}
          <div className="hover:scale-105 transition-transform duration-300">
            <h3 className="text-2xl font-bold text-foreground mb-8">Get in Touch</h3>

            <div className="space-y-6">
              <div className="flex items-center space-x-4 hover:scale-105 transition-transform duration-300">
                <div className="w-12 h-12 bg-purple-400/20 rounded-lg flex items-center justify-center">
                  <Mail className="h-6 w-6 text-purple-400" />
                </div>
                <div>
                  <h4 className="text-foreground font-semibold">Email</h4>
                  <p className="text-muted-foreground">mishradiv2002@gmail.com</p>
                </div>
              </div>

              <div className="flex items-center space-x-4 hover:scale-105 transition-transform duration-300">
                <div className="w-12 h-12 bg-purple-400/20 rounded-lg flex items-center justify-center">
                  <Phone className="h-6 w-6 text-purple-400" />
                </div>
                <div>
                  <h4 className="text-foreground font-semibold">Phone</h4>
                  <p className="text-muted-foreground">+91-9424524617</p>
                </div>
              </div>

              <div className="flex items-center space-x-4 hover:scale-105 transition-transform duration-300">
                <div className="w-12 h-12 bg-purple-400/20 rounded-lg flex items-center justify-center">
                  <MapPin className="h-6 w-6 text-purple-400" />
                </div>
                <div>
                  <h4 className="text-foreground font-semibold">Location</h4>
                  <p className="text-muted-foreground">Bhopal, India</p>
                </div>
              </div>
            </div>

            <div className="mt-8">
              <h4 className="text-foreground font-semibold mb-4">Follow Me</h4>
              <div className="flex space-x-4">
                <Button
                  variant="outline"
                  size="icon"
                  className="border-purple-400 text-purple-400 hover:bg-purple-400 hover:text-black hover:scale-110 transition-all duration-300"
                  onClick={() => window.open("https://github.com/divyansh-mishra", "_blank")}
                >
                  <Github className="h-5 w-5" />
                </Button>
                <Button
                  variant="outline"
                  size="icon"
                  className="border-purple-400 text-purple-400 hover:bg-purple-400 hover:text-black hover:scale-110 transition-all duration-300"
                >
                  <Linkedin className="h-5 w-5" />
                </Button>
              </div>
            </div>
          </div>

          {/* Contact Form */}
          <div className="hover:scale-105 transition-transform duration-300">
            <h3 className="text-2xl font-bold text-foreground mb-8">Send a Message</h3>

            <form onSubmit={handleSubmit} className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <Input
                    name="name"
                    value={formData.name}
                    onChange={handleChange}
                    placeholder="Your Name"
                    required
                    className="bg-card border-purple-500/20 text-foreground placeholder-muted-foreground focus:border-purple-400"
                  />
                </div>
                <div>
                  <Input
                    type="email"
                    name="email"
                    value={formData.email}
                    onChange={handleChange}
                    placeholder="Your Email"
                    required
                    className="bg-card border-purple-500/20 text-foreground placeholder-muted-foreground focus:border-purple-400"
                  />
                </div>
              </div>

              <div>
                <Input
                  name="subject"
                  value={formData.subject}
                  onChange={handleChange}
                  placeholder="Subject"
                  required
                  className="bg-card border-purple-500/20 text-foreground placeholder-muted-foreground focus:border-purple-400"
                />
              </div>

              <div>
                <Textarea
                  name="message"
                  value={formData.message}
                  onChange={handleChange}
                  placeholder="Your Message"
                  rows={6}
                  required
                  className="bg-card border-purple-500/20 text-foreground placeholder-muted-foreground focus:border-purple-400 resize-none"
                />
              </div>

              <Button
                type="submit"
                className="w-full bg-purple-400 text-black hover:bg-purple-500 hover:scale-105 transition-all duration-300"
              >
                Send Message
              </Button>
            </form>
          </div>
        </div>

        {/* Footer */}
        <div className="mt-16 pt-8 border-t border-purple-500/20 text-center">
          <p className="text-muted-foreground">© 2024 Divyansh Mishra. Built with Next.js and Tailwind CSS.</p>
        </div>
      </div>
    </section>
  )
}
