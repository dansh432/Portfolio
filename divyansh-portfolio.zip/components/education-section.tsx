"use client"

import { GraduationCap } from "lucide-react"

export function EducationSection() {
  const education = [
    {
      period: "2021 – Present",
      institution: "Lakshmi Narain College of Technology and Science, Bhopal",
      degree: "Bachelor's Degree in Computer Science (Blockchain Specialization)",
      grade: "CGPA: 7.00",
      description: "Specialized coursework in blockchain technology, smart contracts, and decentralized applications.",
    },
    {
      period: "2021",
      institution: "C.K.M. Higher Secondary School",
      degree: "12th Grade",
      grade: "Percentage: 73.6%",
      description: "Science stream with focus on Mathematics and Computer Science.",
    },
    {
      period: "2019",
      institution: "C.K.M. Higher Secondary School",
      degree: "10th Grade",
      grade: "Percentage: 74.6%",
      description: "Strong foundation in core subjects with excellent performance.",
    },
  ]

  return (
    <section id="education" className="py-20 px-4 relative z-10">
      <div className="max-w-4xl mx-auto">
        <div className="flex items-center justify-center mb-12">
          <GraduationCap className="h-8 w-8 text-purple-400 mr-3" />
          <h2 className="text-3xl lg:text-4xl font-bold text-purple-400">Education</h2>
        </div>

        <div className="space-y-8">
          {education.map((edu, index) => (
            <div
              key={index}
              className="relative pl-8 border-l-2 border-purple-500/30 hover:border-purple-400 transition-colors duration-300 group"
            >
              <div className="absolute -left-2 top-0 w-4 h-4 bg-purple-400 rounded-full group-hover:scale-125 transition-transform duration-300"></div>
              <div className="mb-2 group-hover:scale-105 transition-transform duration-300">
                <span className="text-purple-400 font-semibold">{edu.period}:</span>
                <span className="text-purple-400 ml-2 font-semibold">{edu.institution}</span>
              </div>
              <h3 className="text-foreground text-lg font-medium mb-1">{edu.degree}</h3>
              <p className="text-muted-foreground mb-2">{edu.grade}</p>
              {edu.description && <p className="text-muted-foreground text-sm italic">{edu.description}</p>}
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}
